/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 3, 2014, 10:32 AM
 */

//System Level Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Define Variables
    float F,C;            //Fahrenheit and Celsius
    
    //Input Variables
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<"What is the temperature in Celsius?"<<endl;
    cin>>C;
    
    //Calculations
    F=((1.8f)*C)+32;
    
    //Output Variables
    cout<<"The temperature, in Fahrenheit, is "<<F<<" degrees."<<endl;
    
    //Run Program, Run!
    return 0;
}

