/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 2, 2014, 11:29 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

// Begin Program
int main(int argc, char** argv) {
    //Define Variables
    float widg,pal,widgPal;                 //Weight of the widgets on the palette, just the palette and just the widgets
    
    //Weight of the widgets individually
    widg=9.2f;
    
    //Find weight of palettes and widgets on the palettes
    cout<<"What is the weight of the palette by itself?"<<endl;
    cin>>pal;
    cout<<"What is the weight of the palette and widgets?"<<endl;
    cin>>widgPal;
    
    //Calculations
    widg=(widgPal-pal)/9.2f;
    
    //Find the number of widgets
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"You have this many widgets "<<widg<<endl;
    
    //Run Program
    return 0;
}

