/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 3, 2014, 12:30 AM
 */

//System Level Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Define Variables
    float cost,insP,tot;            //Stands for the cost of repairs and percentage of cost
    
    insP=.8f;
    
    //Input Variables
    cout<<"How much would the repairs cost?"<<endl;
    cin>>cost;
    
    //Calculations
    tot=cost*insP;
    
    //Output Variables
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<"Your total would be "<<tot<<endl;
    
    //Run Program, Run
    return 0;
}

