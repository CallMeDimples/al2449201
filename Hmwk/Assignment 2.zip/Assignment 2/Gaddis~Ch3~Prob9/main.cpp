/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 3, 2014, 10:19 AM
 */

//System Level Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Define Variables
    float loanP,ins,gas,oil,tires,maint,
            totM,totY;
    
    //Input Variables 
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"Each month what is the cost of each:"<<endl;
    cout<<"Loan payments?"<<endl;
    cin>>loanP;
    cout<<"Insurance?"<<endl;
    cin>>ins;
    cout<<"Gas?"<<endl;
    cin>>gas;
    cout<<"Oil?"<<endl;
    cin>>oil;
    cout<<"Tires?"<<endl;
    cin>>tires;
    cout<<"Maintenence?"<<endl;
    cin>>maint;
    
    //Calculations
    totM=loanP+ins+gas+oil+tires+maint;
    
    totY=totM*12;
    
    //Output Variables
    cout<<"Your total payments each month are $"<<totM<<endl;
    cout<<"Your total payments each years are $"<<totY<<endl;
    
    //Run Program, Run
    return 0;
}

