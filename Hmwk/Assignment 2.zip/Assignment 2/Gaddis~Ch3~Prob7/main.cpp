/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 2, 2014, 11:58 PM
 */

//System Level Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Define Variables
    unsigned short bag;       //Cookies in a bag eaten
    float srvng,cal;      //Individual calorie count, serving size
    
    //Input values
    cout<<"How many cookies did you eat?"<<endl;
    cin>>bag;
    
    //Calculations
    srvng=bag/4.0f;
    cal=srvng*300.0f;
    
    //Output Values
    cout<<"You ate "<<cal<<" calories"<<endl;
    
    //Run Program
    return 0;
}

