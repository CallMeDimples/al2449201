/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 3, 2014, 10:55 AM
 */

//System Level Libraries
#include <iostream>
#include <string>
using namespace std;

//User Libraries

//Global COnstants

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Define Variables
    string name,city,age,college,
            profession,animal,petName;     //Variables are personal information
    
    //Input Variables
    cout<<"Enter the following:"<<endl;
    cout<<"Name"<<endl;
    getline(cin,name);
    cout<<"Age"<<endl;
    getline(cin,age);
    cout<<"City of Residence"<<endl;
    getline(cin,city);
    cout<<"College attended"<<endl;
    getline(cin,college);
    cout<<"Profession"<<endl;
    getline(cin,profession);
    cout<<"Breed of Pet"<<endl;
    getline(cin,animal);
    cout<<"Name of pet"<<endl;
    getline(cin,petName);
    cout<<"\n"<<endl;
    
    //Output Story
    cout<<"There once was a person named "<<name<<" who lived in "
            ""<<city<<". At the age of "<<age<<", "<<name<<" went to "
            "college at "<<college<<".\n "<<name<<" graduated and went to work as "
            "a "<<profession<<". Then, "<<name<<" adopted a(n) "<<animal<<" "
            "named "<<petName<<".\n They both lived happily ever after."<<endl;
    
    //Run Program, Run
    return 0;
}

