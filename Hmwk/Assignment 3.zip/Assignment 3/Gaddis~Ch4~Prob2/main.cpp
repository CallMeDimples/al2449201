/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 7, 2014, 10:28 AM
 */

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants 

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Define variables
    int num;        //The number being replaced
    
    //Output
    cout<<"Insert a number from 1 to 10."<<endl;
    cout<<"I will make it a roman numeral."<<endl;
    cin>>num;
    cout<<"\n";
    //Use a switch statement
    switch (num){
        case 1:
            cout<<"I\n";
            break;
        case 2:
            cout<<"II\n";
            break;
        case 3:
            cout<<"III\n";
            break;
        case 4:
            cout<<"IV\n";
            break;
        case 5:
            cout<<"V\n";
            break;
        case 6:
            cout<<"VI\n";
            break;
        case 7:
            cout<<"VII\n";
            break;
        case 8:
            cout<<"VIII\n";
            break;
        case 9:
            cout<<"IX\n";
            break;
        case 10:
            cout<<"X\n";
            break;
        default:
            cout<<"I said 1 through 10.\n";
    }
    cout<<"Thank you."<<endl;
    return 0;
}

