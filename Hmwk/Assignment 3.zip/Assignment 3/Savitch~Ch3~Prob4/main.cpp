/* 
 * File:   main.cpp
 * Author: Allison Lomheim
 * Created on July 7, 2014, 10:28 AM
 */

#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants 

//Function Prototypes

//Begin Program
int main(int argc, char** argv) {
    //Display Variables
    int monthN;      //Months will be entered as numbers 
    int day;         //Days needed to define whether on the cusp or not
    
    //Input variables
    cout<<"Please enter the month of birth.\n";
    cin>>monthN;
    cout<<"Now enter the day. And please choose\n "
            "a day acceptable for the month."<<endl;
    cin>>day;
            
    //If else statement
    if ((monthN==3&&(day>=21&&day<=31))||(monthN==4&&(day<=19&&day>0)))
    {
        if ((monthN==3&&(day>=21&&day<=23))||(monthN==4&&(day<=19&&day>17)))
        {
            cout<<"You're an Aries and you are on the cusp!\n";
        }else
        {  
        cout<<"You are an Aries.\n";
        }
    }else if ((monthN==4&&(day>=20&&day<=30))||(monthN==5&&(day<=20&&day>0)))
    {
        if ((monthN==4&&(day>=20&&day<=22))||(monthN==5&&(day<=20&&day>18)))
        {
            cout<<"You're a Taurus and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Taurus.\n";
        }
    }else if ((monthN==5&&(day>=21&&day<=31))||(monthN==6&&(day<=21&&day>0)))
    {
        if ((monthN==5&&(day>=21&&day<=23))||(monthN==6&&(day<=21&&day>19)))
        {
            cout<<"You're a Gemini and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Gemini.\n";
        }
    }else if ((monthN==6&&(day>=22&&day<=30))||(monthN==7&&(day<=22&&day>0)))
    {
        if ((monthN==6&&(day>=22&&day<=24))||(monthN==7&&(day<=22&&day>20)))
        {
            cout<<"You're a Cancer and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Cancer.\n";
        }
    }else if ((monthN==7&&(day>=23&&day<=31))||(monthN==8&&(day<=22&&day>0)))
    {
        if ((monthN==7&&(day>=23&&day<=25))||(monthN==8&&(day<=22&&day>20)))
        {
            cout<<"You're a Leo and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Leo.\n";
        }
    }else if ((monthN==8&&(day>=23&&day<=31))||(monthN==9&&(day<=22&&day>0)))
    {        
        if ((monthN==8&&(day>=23&&day<=25))||(monthN==9&&(day<=22&&day>20)))
        {
            cout<<"You're a Virgo and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Virgo.\n";
        }
    }else if ((monthN==9&&(day>=23&&day<=30))||(monthN==10&&(day<=22&&day>0)))
    {
        if ((monthN==9&&(day>=23&&day<=25))||(monthN==10&&(day<=22&&day>20)))
        {
            cout<<"You're a Libra and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Libra.\n";
        }
    }else if ((monthN==10&&(day>=23&&day<=31))||(monthN==11&&(day<=21&&day>0)))
    {
        if ((monthN==10&&(day>=23&&day<=25))||(monthN==11&&(day<=21&&day>19)))
        {
            cout<<"You're a Scorpio and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Scorpio.\n";
        }
    }else if ((monthN==11&&(day>=22&&day<=30))||(monthN==12&&(day<=21&&day>0)))
    {
        if ((monthN==11&&(day>=22&&day<=24))||(monthN==12&&(day<=21&&day>19)))
        {
            cout<<"You're a Sagittarius and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Sagittarius.\n";
        }
    }else if ((monthN==12&&(day>=22&&day<=31))||(monthN==1&&(day<=22&&day>0)))
    {
        if ((monthN==12&&(day>=22&&day<=24))||(monthN==1&&(day<=22&&day>20)))
        {
            cout<<"You're a Capricorn and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Capricorn.\n";
        }
    }else if ((monthN==1&&(day>=20&&day<=31))||(monthN==2&&(day<=18&&day>0)))
    {
        if ((monthN==1&&(day>=20&&day<=22))||(monthN==2&&(day<=18&&day>16)))
        {
            cout<<"You're an Aquarius and you are on the cusp!\n";
        }else
        {  
            cout<<"You are an Aquarius.\n";
        }
    }else if ((monthN==2&&(day>=19&&day<=29))||(monthN==3&&(day<=20&&day>0)))
    {
        if ((monthN==2&&(day>=19&&day<=21))||(monthN==3&&(day<=20&&day>18)))
        {
            cout<<"You're a Pisces and you are on the cusp!\n";
        }else
        {  
            cout<<"You are a Pisces.\n";
        }
    }else
    {
        cout<<"Your input was not correct."<<endl;
    }
    
    //Congratulate
    cout<<"That is your horoscope.\n\n"<<endl;
    
    //Use another if else statement
    if ((monthN==3&&(day>=21&&day<=31))||(monthN==4&&(day<=19&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                " Aries, Leo, and or Sagittarius";
    }else if ((monthN==4&&(day>=20&&day<=30))||(monthN==5&&(day<=20&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Taurus, Virgo, or Capricorn.";
    }else if ((monthN==5&&(day>=21&&day<=31))||(monthN==6&&(day<=21&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Gemini, Libra or Aquarius.";
    }else if ((monthN==6&&(day>=22&&day<=30))||(monthN==7&&(day<=22&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Cancer, Scorpio or Pisces.";
    }else if ((monthN==7&&(day>=23&&day<=31))||(monthN==8&&(day<=22&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                " Aries, Leo, and or Sagittarius";
    }else if ((monthN==8&&(day>=23&&day<=31))||(monthN==9&&(day<=22&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Taurus, Virgo, or Capricorn.";
    }else if ((monthN==9&&(day>=23&&day<=30))||(monthN==10&&(day<=22&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Gemini, Libra or Aquarius.";
    }else if ((monthN==10&&(day>=23&&day<=31))||(monthN==11&&(day<=21&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Cancer, Scorpio or Pisces.";
    }else if ((monthN==11&&(day>=22&&day<=30))||(monthN==12&&(day<=21&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                " Aries, Leo, and or Sagittarius";
    }else if ((monthN==12&&(day>=22&&day<=31))||(monthN==1&&(day<=22&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Taurus, Virgo, or Capricorn.";
    }else if ((monthN==1&&(day>=20&&day<=31))||(monthN==2&&(day<=18&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Gemini, Libra or Aquarius.";
    }else if ((monthN==2&&(day>=19&&day<=29))||(monthN==3&&(day<=20&&day>0)))
    {
        cout<<"You would get along well with others who are either\n"
                "Cancer, Scorpio or Pisces.";
    }else
    {
        cout<<"You pair with no one cause you didn't type something\n"
                "in correctly.";
    }
    
    //Run Program, Run
    return 0;
}
